import random

# Base class for items
class Item:
    def __init__(self, name, description, uses):
        self.name = name
        self.description = description
        self.uses = uses

    def use(self):
        if self.uses > 0:
            self.uses -= 1
            return True  # Item used successfully
        else:
            print(f"The {self.name} has no more uses.")
            return False  # No uses left


# Inventory system
class Inventory:
    def __init__(self):
        self.items = []

    def add_item(self, item):
        self.items.append(item)

    def remove_item(self, item_name):
        self.items = [item for item in self.items if item.name != item_name]

    def show_inventory(self):
        print("Inventory:")
        for item in self.items:
            print(f"{item.name} - {item.description} (Uses: {item.uses})")
        print("\n")


# Crafting function
def craft_item(inventory, recipe, crafted_item):
    # Check if the player has all items required for crafting
    for required_item in recipe:
        if not any(item.name == required_item for item in inventory.items):
            print(f"You don't have all the components to craft {crafted_item.name}.")
            return False

    # If all items are available, craft the item
    for required_item in recipe:
        inventory.remove_item(required_item)  # Remove used components
    inventory.add_item(crafted_item)  # Add the crafted item
    print(f"You crafted {crafted_item.name}!")
    return True


# Mini-games: Lockpicking
def lockpicking_mini_game():
    secret_number = random.randint(1, 5)  # Random number between 1 and 5
    attempts = 3

    print("Lockpicking Mini-Game: Guess the number (1-5) to unlock the door!")
    while attempts > 0:
        guess = int(input(f"Enter your guess (Attempts left: {attempts}): "))
        if guess == secret_number:
            print("Success! You unlocked the door.")
            return True
        else:
            attempts -= 1
            print("Wrong guess.")

    print("Failed! You couldn't unlock the door.")
    return False


# Mini-games: Puzzle
def puzzle_mini_game():
    correct_combination = [1, 2, 3]  # Example puzzle solution
    attempts = 3

    print("Puzzle Mini-Game: Solve the puzzle by entering the correct combination of 3 switches!")
    while attempts > 0:
        guess = [int(input(f"Enter guess for switch {i+1} (1, 2, or 3): ")) for i in range(3)]
        if guess == correct_combination:
            print("Success! You solved the puzzle.")
            return True
        else:
            attempts -= 1
            print("Wrong combination.")

    print("Failed! You couldn't solve the puzzle.")
    return False


# Monster class
class Monster:
    def __init__(self, name, health, description, attack_description):
        self.name = name
        self.health = health
        self.description = description
        self.attack_description = attack_description

    def attack(self, player_health):
        print(self.attack_description)
        return player_health - 20  # Example damage

    def take_damage(self, damage):
        self.health -= damage
        print(f"The {self.name} took {damage} damage! (Health: {self.health})")
        if self.health <= 0:
            print(f"The {self.name} has been defeated.")
            return True  # Monster defeated
        return False


# Combat system
def combat(player_health, monster):
    print(f"A {monster.name} appears! {monster.description}")
    while monster.health > 0 and player_health > 0:
        action = input("Do you want to 'attack' or 'flee'? ").lower()
        if action == "attack":
            monster.take_damage(15)  # Example player attack damage
            if monster.health > 0:
                player_health = monster.attack(player_health)
                print(f"Your health: {player_health}")
        elif action == "flee":
            print("You successfully fled.")
            break

    return player_health


# Example items and crafting recipes
flashlight = Item("Flashlight", "Reveals hidden paths. Duration: 3 uses.", 3)
charm = Item("Protective Charm", "Grants temporary immunity from monsters.", 1)
matches = Item("Matches", "Can be used to ignite or craft.", 1)
fabric = Item("Fabric", "Used for crafting.", 1)
bottle = Item("Bottle", "Empty bottle for crafting.", 1)
sleeping_pills = Item("Sleeping Pills", "Restores 20 health.", 1)

molotov_cocktail_recipe = ["Matches", "Fabric", "Bottle"]
molotov_cocktail = Item("Molotov Cocktail", "Deals heavy damage to monsters.", 1)

# Example inventory
player_inventory = Inventory()
player_inventory.add_item(flashlight)
player_inventory.add_item(charm)
player_inventory.add_item(matches)
player_inventory.add_item(fabric)
player_inventory.add_item(bottle)


# Gameplay loop
def gameplay_loop():
    player_health = 100

    # Explore loop
    while player_health > 0:
        action = input("You are exploring. Do you want to 'search', 'craft', or 'open inventory'? ").lower()

        if action == 'search':
            print("You found a locked door. Let's try to pick the lock.")
            if lockpicking_mini_game():
                print("You opened the door.")
            else:
                print("You failed to open the door.")

        elif action == 'craft':
            print("Crafting menu:")
            craft_item(player_inventory, molotov_cocktail_recipe, molotov_cocktail)

        elif action == 'open inventory':
            player_inventory.show_inventory()

        # Random monster encounter
        if random.randint(0, 1):  # 50% chance of encountering a monster
            shadowy_figure = Monster("Shadowy Figure", 50, "A terrifying figure that paralyzes its victims.", "The shadowy figure attacks!")
            player_health = combat(player_health, shadowy_figure)

        if player_health <= 0:
            print("You have been defeated by the monsters...")


# Start the game
gameplay_loop()
